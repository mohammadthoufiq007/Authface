"""
OffaceFace — REST API for Datalake 3.0 Integration
Runs on localhost:8000 only — zero network exposure.

Usage:
  pip install fastapi uvicorn python-multipart
  uvicorn offaceface.api:app --host 127.0.0.1 --port 8000
"""

import base64
import os
import sys
import numpy as np
import cv2

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
from offaceface.pipeline import FaceSystem

# ── App setup ─────────────────────────────────────────────────────────────────
app = FastAPI(
    title="OffaceFace API",
    description="Offline facial recognition and liveness detection for Datalake 3.0",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost", "http://127.0.0.1"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load FaceSystem once at startup
_fs: Optional[FaceSystem] = None

@app.on_event("startup")
async def startup():
    global _fs
    print("Loading OffaceFace models...")
    _fs = FaceSystem()
    print("All models loaded. API ready.")

def get_fs() -> FaceSystem:
    if _fs is None:
        raise HTTPException(status_code=503, detail="Models not loaded yet")
    return _fs

def decode_frame(frame_base64: str) -> np.ndarray:
    try:
        img_bytes = base64.b64decode(frame_base64)
        img_array = np.frombuffer(img_bytes, dtype=np.uint8)
        frame = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
        if frame is None:
            raise ValueError("Could not decode image")
        return frame
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid image: {e}")

# ── Request/Response models ────────────────────────────────────────────────────
class VerifyRequest(BaseModel):
    frame_base64: str

class VerifyResponse(BaseModel):
    status: str
    identity: Optional[str]
    confidence: float
    is_live: Optional[bool]
    liveness_score: Optional[float]

class EnrollRequest(BaseModel):
    name: str
    frames_base64: List[str]

class EnrollResponse(BaseModel):
    enrolled: bool
    name: str
    frames_used: int
    message: str

class DeleteResponse(BaseModel):
    deleted: bool
    name: str

class EnrolledResponse(BaseModel):
    people: List[str]
    count: int

class HealthResponse(BaseModel):
    status: str
    models_loaded: bool
    version: str
    offline: bool

# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.get("/", response_model=HealthResponse)
async def health():
    """Health check — confirms system is ready."""
    return HealthResponse(
        status="ok",
        models_loaded=_fs is not None,
        version="1.0.0",
        offline=True,
    )

@app.post("/verify", response_model=VerifyResponse)
async def verify(request: VerifyRequest):
    """
    Verify a face in a frame.
    Returns identity match, liveness result, and confidence.
    """
    fs = get_fs()
    frame = decode_frame(request.frame_base64)
    result = fs.verify(frame)
    return VerifyResponse(
        status=result.get("status", "ERROR"),
        identity=result.get("identity"),
        confidence=result.get("confidence", 0.0),
        is_live=result.get("is_live"),
        liveness_score=result.get("liveness_score"),
    )

@app.post("/enroll", response_model=EnrollResponse)
async def enroll(request: EnrollRequest):
    """
    Enroll a new person with multiple face frames.
    Minimum 3 frames recommended for accuracy.
    """
    fs = get_fs()
    if not request.name.strip():
        raise HTTPException(status_code=400, detail="Name cannot be empty")
    if not request.frames_base64:
        raise HTTPException(status_code=400, detail="At least one frame required")

    frames = []
    for fb64 in request.frames_base64:
        try:
            frames.append(decode_frame(fb64))
        except Exception:
            continue

    if not frames:
        raise HTTPException(status_code=400, detail="No valid frames provided")

    success = fs.enroll(request.name.strip(), frames)

    if success:
        return EnrollResponse(
            enrolled=True,
            name=request.name,
            frames_used=len(frames),
            message=f"Successfully enrolled '{request.name}'"
        )
    else:
        return EnrollResponse(
            enrolled=False,
            name=request.name,
            frames_used=0,
            message="Enrollment failed — no valid live faces detected in frames"
        )

@app.get("/enrolled", response_model=EnrolledResponse)
async def list_enrolled():
    """List all enrolled people."""
    fs = get_fs()
    try:
        people = fs.database.list_all_users()
    except AttributeError:
        # Fallback if list_all_users not implemented
        people = []
    return EnrolledResponse(people=people, count=len(people))

@app.delete("/enrolled/{name}", response_model=DeleteResponse)
async def delete_enrolled(name: str):
    """Remove a person from the database."""
    fs = get_fs()
    deleted = fs.database.delete_user(name)
    return DeleteResponse(deleted=deleted, name=name)

@app.get("/audit")
async def get_audit_log(limit: int = 50):
    """Return recent audit log entries."""
    log_path = "data/logs/audit.log"
    if not os.path.exists(log_path):
        return {"entries": [], "total": 0}
    import json
    entries = []
    with open(log_path) as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except Exception:
                    pass
    entries = entries[-limit:]
    entries.reverse()
    return {"entries": entries, "total": len(entries)}
