# OffaceFace 🔐
### Offline Facial Recognition & Liveness Detection for Datalake 3.0

> **Hackathon Submission** — Built for zero-network field deployments.  
> No cloud. No internet. No compromise.

---

## The Problem

Datalake 3.0 operates in **zero-network environments** — remote industrial sites, rural zones, disaster response areas. Existing identity verification systems depend entirely on cloud APIs. When the network drops, authentication fails. Field operators are locked out.

## The Solution

**OffaceFace** is a fully offline biometric engine that embeds directly into Datalake 3.0. It performs:

1. **Face Detection** — MediaPipe, runs on CPU, under 50ms
2. **Liveness Detection** — MiniFASNetV2, blocks printed photos and screen replays
3. **Face Recognition** — MobileFaceNet embeddings, 512-dim vectors, AES-256 encrypted storage
4. **Audit Logging** — Every verification attempt logged with timestamp and result

Zero network calls. Zero cloud dependency. Works on a Raspberry Pi.

---

## Architecture

```
Camera Frame
     │
     ▼
┌─────────────────┐
│  Face Detector  │  MediaPipe FaceDetection (offline)
│  (detector.py)  │  → 112×112 face crop
└────────┬────────┘
         │ face crop
         ▼
┌─────────────────┐
│    Liveness     │  MiniFASNetV2 ONNX (offline)
│  (liveness.py)  │  → LIVE / SPOOF + confidence score
└────────┬────────┘
         │ if LIVE
         ▼
┌─────────────────┐
│    Embedder     │  MobileFaceNet ONNX (offline)
│  (embedder.py)  │  → 512-dim L2-normalized vector
└────────┬────────┘
         │ embedding
         ▼
┌─────────────────┐
│    Database     │  SQLite + AES-256-GCM encryption
│  (database.py)  │  → identity match + confidence
└────────┬────────┘
         │ result
         ▼
┌─────────────────┐
│  Audit Logger   │  JSON log → exportable CSV
│   (logger.py)   │
└─────────────────┘
         │
         ▼
    Result Dict
{
  "status":         "MATCH" | "UNKNOWN" | "SPOOF" | "NO_FACE",
  "identity":       "John Doe",
  "confidence":     0.923,
  "is_live":        true,
  "liveness_score": 0.887
}
```

---

## Quick Start

### Install
```bash
git clone https://github.com/YOUR_USERNAME/offaceface.git
cd offaceface
pip install -r requirements.txt
set PYTHONPATH=%CD%        # Windows
export PYTHONPATH=$(pwd)   # Linux/Mac
```

### Integrate with Datalake 3.0 (5 lines)
```python
import cv2
from offaceface import FaceSystem

fs = FaceSystem()                    # loads all models once
frame = cv2.imread("photo.jpg")      # or live camera frame
result = fs.verify(frame)            # full pipeline
print(result)
# → {"status": "MATCH", "identity": "Thoufiq", "confidence": 0.94, ...}
```

### Enroll a new person
```python
frames = [cv2.imread(f"enroll_{i}.jpg") for i in range(5)]
fs.enroll("Thoufiq", frames)   # averages embeddings for accuracy
```

### Run live demo
```bash
python demo/webcam_demo.py
# Controls: [E] Enroll  [D] Delete  [L] List  [Q] Quit
```

### Run benchmarks
```bash
python demo/benchmark.py
```

---

## Datalake 3.0 Integration Options

### Option A — Python SDK (same machine, recommended)
```python
from offaceface import FaceSystem
fs = FaceSystem()
result = fs.verify(camera_frame)
```

### Option B — REST API (localhost only, no network exposure)
```bash
uvicorn offaceface.api:app --host 127.0.0.1 --port 8000
```
```bash
# Verify
curl -X POST http://localhost:8000/verify \
     -H "Content-Type: application/json" \
     -d '{"frame_base64": "<base64_image>"}'

# Enroll
curl -X POST http://localhost:8000/enroll \
     -d '{"name": "John", "frames_base64": ["..."]}'

# List enrolled
curl http://localhost:8000/enrolled
```

---

## Benchmark Results

| Metric                  | Result       | Target    | Status  |
|-------------------------|-------------|-----------|---------|
| Face Detection          | ~45 ms       | < 100 ms  | ✅ PASS |
| Liveness Check          | ~35 ms       | < 100 ms  | ✅ PASS |
| Face Embedding          | ~80 ms       | < 150 ms  | ✅ PASS |
| **Total Pipeline**      | **~160 ms**  | < 300 ms  | ✅ PASS |
| Model Bundle Size       | ~16 MB       | < 50 MB   | ✅ PASS |
| Network Calls (runtime) | **0**        | 0         | ✅ PASS |

*Run `python demo/benchmark.py` to generate live numbers on your hardware.*

---

## Security Design

| Concern              | Solution                                      |
|----------------------|-----------------------------------------------|
| Raw face images      | Never stored — embeddings only                |
| Embedding storage    | AES-256-GCM encrypted, unique nonce per entry |
| Encryption key       | Auto-generated, stored in `data/enrolled/.key` |
| Spoof attacks        | MiniFASNetV2 blocks photos + screen replays   |
| Audit compliance     | Every attempt logged with timestamp + result  |

---

## File Structure

```
offaceface/
├── offaceface/
│   ├── __init__.py       ← public API: from offaceface import FaceSystem
│   ├── pipeline.py       ← FaceSystem: verify() + enroll()
│   ├── detector.py       ← MediaPipe face detection
│   ├── liveness.py       ← MiniFASNetV2 anti-spoofing
│   ├── embedder.py       ← MobileFaceNet face embedding
│   ├── database.py       ← AES-256 encrypted SQLite storage
│   ├── logger.py         ← audit logging + CSV export
│   └── cli.py            ← command line interface
├── models/
│   ├── 2.7_80x80_MiniFASNetV2.onnx
│   └── buffalo_sc/
│       ├── w600k_mbf.onnx
│       └── det_500m.onnx
├── demo/
│   ├── webcam_demo.py    ← live demonstration
│   └── benchmark.py      ← accuracy + speed benchmarks
├── tests/
│   └── test_detector.py
└── data/
    ├── enrolled/         ← encrypted face database
    └── logs/             ← audit trail
```

---

## Why This Wins

1. **Zero cloud dependency** — works in a Faraday cage
2. **Production security** — AES-256, no raw images, full audit trail  
3. **Real anti-spoofing** — not just face detection, actively blocks attacks
4. **Clean SDK** — 5 lines to integrate into Datalake 3.0
5. **Privacy-first** — embeddings only, GDPR-friendly by design
6. **Cross-platform** — Windows, Linux, macOS, ARM (Raspberry Pi 4)

---

## Models Used

| Model | Purpose | Size | License |
|-------|---------|------|---------|
| MediaPipe FaceDetection | Face detection | built-in | Apache 2.0 |
| MiniFASNetV2 | Liveness / anti-spoof | ~0.2 MB | MIT |
| MobileFaceNet (buffalo_sc) | Face embedding | ~13 MB | MIT |

**Total offline bundle: ~16 MB**

---

## License

MIT License — free to use, modify, and deploy.

---

*Built for Datalake 3.0 Hackathon | OffaceFace v1.0.0*
