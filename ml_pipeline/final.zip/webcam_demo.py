"""
OffaceFace — Live Webcam Demo
Hackathon demonstration script for Datalake 3.0 integration.

Controls:
  E — Enroll a new face
  D — Delete a person
  L — Toggle list of enrolled users
  Q — Quit

Usage:
  python demo/webcam_demo.py
"""

import cv2
import numpy as np
import time
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from offaceface.pipeline import FaceSystem
from offaceface.detector import FaceDetector

# ── Color palette ──────────────────────────────────────────────────────────────
C_LIVE    = (0, 230, 118)      # green
C_SPOOF   = (0, 60, 255)       # red
C_UNKNOWN = (0, 165, 255)      # orange
C_MATCH   = (0, 230, 118)      # green
C_BOX     = (180, 180, 180)    # grey
C_WHITE   = (255, 255, 255)
C_BLACK   = (0, 0, 0)
C_ACCENT  = (147, 51, 234)     # violet

# ── Overlay helpers ────────────────────────────────────────────────────────────
def draw_rounded_rect(img, pt1, pt2, color, thickness=2, r=12):
    x1, y1 = pt1; x2, y2 = pt2
    cv2.line(img, (x1+r, y1), (x2-r, y1), color, thickness)
    cv2.line(img, (x1+r, y2), (x2-r, y2), color, thickness)
    cv2.line(img, (x1, y1+r), (x1, y2-r), color, thickness)
    cv2.line(img, (x2, y1+r), (x2, y2-r), color, thickness)
    cv2.ellipse(img, (x1+r, y1+r), (r, r), 180, 0, 90, color, thickness)
    cv2.ellipse(img, (x2-r, y1+r), (r, r), 270, 0, 90, color, thickness)
    cv2.ellipse(img, (x1+r, y2-r), (r, r),  90, 0, 90, color, thickness)
    cv2.ellipse(img, (x2-r, y2-r), (r, r),   0, 0, 90, color, thickness)

def draw_glass_panel(img, x, y, w, h, alpha=0.55):
    overlay = img.copy()
    cv2.rectangle(overlay, (x, y), (x+w, y+h), (15, 15, 25), -1)
    cv2.addWeighted(overlay, alpha, img, 1-alpha, 0, img)
    cv2.rectangle(img, (x, y), (x+w, y+h), (60, 60, 80), 1)

def put_text_shadow(img, text, pos, font, scale, color, thickness=1):
    x, y = pos
    cv2.putText(img, text, (x+1, y+1), font, scale, (0,0,0), thickness+1, cv2.LINE_AA)
    cv2.putText(img, text, pos,        font, scale, color,   thickness,   cv2.LINE_AA)

def draw_confidence_bar(img, x, y, w, confidence, color):
    bar_h = 6
    cv2.rectangle(img, (x, y), (x+w, y+bar_h), (40, 40, 50), -1)
    fill = int(w * min(confidence, 1.0))
    if fill > 0:
        cv2.rectangle(img, (x, y), (x+fill, y+bar_h), color, -1)
    cv2.rectangle(img, (x, y), (x+w, y+bar_h), (80, 80, 90), 1)

# ── Main Demo ─────────────────────────────────────────────────────────────────
def main():
    print("\n" + "="*55)
    print("  OffaceFace — Offline Facial Recognition System")
    print("  Datalake 3.0 Integration Demo")
    print("="*55)
    print("  Loading models (offline, no network needed)...")

    fs = FaceSystem()
    detector = FaceDetector(model_selection=1)

    print("  ✓ MediaPipe Face Detector loaded")
    print("  ✓ MiniFASNetV2 Liveness Model loaded")
    print("  ✓ MobileFaceNet Embedder loaded")
    print("  ✓ Encrypted SQLite Database ready")
    print("\n  Controls: [E] Enroll  [D] Delete  [L] List  [Q] Quit\n")

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("ERROR: Cannot open webcam.")
        return

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

    # State
    fps_list = []
    last_result = None
    show_enrolled = False
    enroll_mode   = False
    enroll_name   = ""
    enroll_frames = []
    enroll_needed = 7
    status_msg    = ""
    status_timer  = 0
    frame_count   = 0

    FONT  = cv2.FONT_HERSHEY_SIMPLEX
    FONTM = cv2.FONT_HERSHEY_DUPLEX

    while True:
        t_start = time.time()
        ret, frame = cap.read()
        if not ret:
            break

        frame = cv2.flip(frame, 1)
        h, w = frame.shape[:2]
        display = frame.copy()
        frame_count += 1

        # ── Dark vignette overlay ──────────────────────────────────────────
        vign = np.zeros_like(display, dtype=np.uint8)
        cv2.rectangle(vign, (0,0), (w,h), (0,0,0), -1)
        for i in range(0, min(w,h)//4, 4):
            alpha_v = int(120 * (i / (min(w,h)//4)))
            cv2.rectangle(vign, (i,i), (w-i,h-i), (0,0,0,), 0)
        cv2.addWeighted(display, 1.0, vign, 0.0, 0, display)

        # ── Detect face ────────────────────────────────────────────────────
        face_crop = detector.detect_face(frame)

        # Draw face bounding box
        import mediapipe as mp
        mp_fd = mp.solutions.face_detection
        with mp_fd.FaceDetection(min_detection_confidence=0.7, model_selection=1) as det:
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = det.process(rgb)
            if results.detections:
                best = max(results.detections, key=lambda d: d.score[0])
                bb = best.location_data.relative_bounding_box
                bx = int(bb.xmin * w)
                by = int(bb.ymin * h)
                bw = int(bb.width * w)
                bh = int(bb.height * h)
                bx = max(0, bx); by = max(0, by)
                bx2 = min(w, bx+bw); by2 = min(h, by+bh)

                box_color = C_BOX
                if last_result:
                    if last_result["status"] == "MATCH":
                        box_color = C_MATCH
                    elif last_result["status"] == "SPOOF":
                        box_color = C_SPOOF
                    elif last_result["status"] == "UNKNOWN":
                        box_color = C_UNKNOWN

                draw_rounded_rect(display, (bx, by), (bx2, by2), box_color, 2, 16)

                # Corner accent lines
                clen = 20
                cv2.line(display, (bx, by), (bx+clen, by), C_WHITE, 2)
                cv2.line(display, (bx, by), (bx, by+clen), C_WHITE, 2)
                cv2.line(display, (bx2, by), (bx2-clen, by), C_WHITE, 2)
                cv2.line(display, (bx2, by), (bx2, by+clen), C_WHITE, 2)
                cv2.line(display, (bx, by2), (bx+clen, by2), C_WHITE, 2)
                cv2.line(display, (bx, by2), (bx, by2-clen), C_WHITE, 2)
                cv2.line(display, (bx2, by2), (bx2-clen, by2), C_WHITE, 2)
                cv2.line(display, (bx2, by2), (bx2, by2-clen), C_WHITE, 2)

        # ── Run pipeline every 3rd frame (performance) ─────────────────────
        if face_crop is not None and frame_count % 3 == 0:
            if enroll_mode:
                # Collect frames for enrollment
                liveness = fs.liveness.verify_liveness(face_crop)
                if liveness["is_live"]:
                    emb = fs.embedder.extract_embedding(face_crop)
                    enroll_frames.append(emb)
                    cv2.putText(display,
                        f"Capturing {len(enroll_frames)}/{enroll_needed} — stay still",
                        (w//2 - 180, h - 80), FONT, 0.7, C_ACCENT, 2, cv2.LINE_AA)
                    if len(enroll_frames) >= enroll_needed:
                        avg = np.mean(enroll_frames, axis=0)
                        avg = avg / np.linalg.norm(avg)
                        fs.database.enroll_user(enroll_name, avg)
                        fs.logger.log({"event": "ENROLLED", "identity": enroll_name,
                                       "frames_used": len(enroll_frames)})
                        status_msg = f"✓ Enrolled '{enroll_name}' successfully"
                        status_timer = 90
                        enroll_mode = False
                        enroll_frames = []
                        enroll_name = ""
            else:
                last_result = fs.verify(frame)

        # ── Result panel (bottom left) ─────────────────────────────────────
        panel_x, panel_y = 20, h - 170
        draw_glass_panel(display, panel_x, panel_y, 320, 150)

        if last_result:
            s = last_result["status"]
            identity   = last_result.get("identity") or "Unknown"
            confidence = last_result.get("confidence", 0.0)
            is_live    = last_result.get("is_live", False)
            lscore     = last_result.get("liveness_score", 0.0)

            # Status badge
            if s == "MATCH":
                badge_color = C_LIVE
                badge_text  = "● VERIFIED"
            elif s == "SPOOF":
                badge_color = C_SPOOF
                badge_text  = "● SPOOF DETECTED"
                identity    = "Attack Blocked"
            elif s == "UNKNOWN":
                badge_color = C_UNKNOWN
                badge_text  = "● UNKNOWN FACE"
            else:
                badge_color = C_BOX
                badge_text  = "● SCANNING..."

            put_text_shadow(display, badge_text,
                (panel_x+12, panel_y+28), FONT, 0.65, badge_color, 2)

            # Identity
            put_text_shadow(display, identity,
                (panel_x+12, panel_y+62), FONTM, 0.9, C_WHITE, 2)

            # Confidence bar
            if s in ("MATCH", "UNKNOWN"):
                put_text_shadow(display, f"Match  {confidence*100:.1f}%",
                    (panel_x+12, panel_y+90), FONT, 0.5, (180,180,180), 1)
                draw_confidence_bar(display, panel_x+12, panel_y+98, 180, confidence, badge_color)

            # Liveness
            lv_color = C_LIVE if is_live else C_SPOOF
            lv_text  = f"Liveness  {lscore*100:.1f}%"
            put_text_shadow(display, lv_text,
                (panel_x+12, panel_y+122), FONT, 0.5, lv_color, 1)
            draw_confidence_bar(display, panel_x+12, panel_y+130, 180, lscore, lv_color)

        else:
            put_text_shadow(display, "● INITIALIZING",
                (panel_x+12, panel_y+28), FONT, 0.6, C_BOX, 1)
            put_text_shadow(display, "Point camera at a face",
                (panel_x+12, panel_y+62), FONT, 0.55, (150,150,150), 1)

        # ── Top bar ────────────────────────────────────────────────────────
        draw_glass_panel(display, 0, 0, w, 44)
        put_text_shadow(display, "OffaceFace  |  Offline Biometric Engine  |  Datalake 3.0",
            (16, 28), FONT, 0.55, (200, 200, 220), 1)

        # FPS counter
        fps_list.append(1.0 / max(time.time() - t_start, 0.001))
        if len(fps_list) > 20:
            fps_list.pop(0)
        fps = sum(fps_list) / len(fps_list)
        put_text_shadow(display, f"FPS {fps:.1f}",
            (w - 100, 28), FONT, 0.55, C_LIVE, 1)

        # ── Controls bar (top right) ───────────────────────────────────────
        draw_glass_panel(display, w-210, 54, 200, 110)
        put_text_shadow(display, "[E] Enroll face",   (w-198, 76),  FONT, 0.48, (180,180,200), 1)
        put_text_shadow(display, "[D] Delete person", (w-198, 100), FONT, 0.48, (180,180,200), 1)
        put_text_shadow(display, "[L] List enrolled", (w-198, 124), FONT, 0.48, (180,180,200), 1)
        put_text_shadow(display, "[Q] Quit",          (w-198, 148), FONT, 0.48, (180,180,200), 1)

        # ── Enrolled list panel ────────────────────────────────────────────
        if show_enrolled:
            try:
                enrolled = fs.database.list_all_users()
            except:
                enrolled = []
            lh = 30 + len(enrolled) * 26
            draw_glass_panel(display, w-210, 174, 200, max(lh, 50))
            put_text_shadow(display, f"Enrolled ({len(enrolled)})",
                (w-198, 196), FONT, 0.55, C_ACCENT, 1)
            for i, name in enumerate(enrolled):
                put_text_shadow(display, f"  {i+1}. {name}",
                    (w-198, 218 + i*26), FONT, 0.48, C_WHITE, 1)
            if not enrolled:
                put_text_shadow(display, "  (none yet)",
                    (w-198, 218), FONT, 0.48, (120,120,120), 1)

        # ── Status message ─────────────────────────────────────────────────
        if status_timer > 0:
            alpha = min(1.0, status_timer / 20.0)
            color = tuple(int(c * alpha) for c in C_LIVE)
            put_text_shadow(display, status_msg,
                (w//2 - 200, h - 30), FONT, 0.65, color, 2)
            status_timer -= 1

        # ── Enroll mode overlay ────────────────────────────────────────────
        if enroll_mode:
            draw_glass_panel(display, w//2 - 220, h//2 - 30, 440, 60)
            put_text_shadow(display,
                f"Enrolling: '{enroll_name}'  ({len(enroll_frames)}/{enroll_needed})",
                (w//2 - 200, h//2 + 8), FONTM, 0.75, C_ACCENT, 2)

        cv2.imshow("OffaceFace — Datalake 3.0 Biometric Engine", display)

        # ── Key handling ───────────────────────────────────────────────────
        key = cv2.waitKey(1) & 0xFF

        if key == ord('q') or key == 27:
            break

        elif key == ord('e') and not enroll_mode:
            print("\nEnter name to enroll: ", end="", flush=True)
            cv2.destroyAllWindows()
            name = input().strip()
            if name:
                enroll_name   = name
                enroll_frames = []
                enroll_mode   = True
                status_msg    = f"Look at the camera — capturing {enroll_needed} frames..."
                status_timer  = 60
            cap_new = cv2.VideoCapture(0)
            cap_new.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
            cap_new.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
            cap.release()
            cap = cap_new

        elif key == ord('d'):
            print("\nEnter name to delete: ", end="", flush=True)
            cv2.destroyAllWindows()
            name = input().strip()
            if name:
                try:
                    deleted = fs.database.delete_user(name)
                    status_msg   = f"✓ Deleted '{name}'" if deleted else f"✗ '{name}' not found"
                    status_timer = 90
                except Exception as ex:
                    status_msg   = f"Error: {ex}"
                    status_timer = 90
            cap_new = cv2.VideoCapture(0)
            cap_new.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
            cap_new.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
            cap.release()
            cap = cap_new

        elif key == ord('l'):
            show_enrolled = not show_enrolled

    cap.release()
    cv2.destroyAllWindows()
    print("\n  Demo ended. Audit log saved to data/logs/audit.log")

if __name__ == "__main__":
    main()
